const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Plugins.System.Cnds.OnLayoutStart
	];
};
self.C3_JsPropNameTable = [
	{精靈: 0},
	{Flame: 0}
];

self.InstanceType = {
	精靈: class extends self.ISpriteInstance {},
	Flame: class extends self.ISpriteInstance {}
}